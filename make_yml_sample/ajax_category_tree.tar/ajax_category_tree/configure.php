<?php
if (!defined('IS_ADMIN_FLAG')) {
  die('Illegal Access');
}
define('MODULE_ADDON_MODULES_AJAXCATEGORYTREE_STATUS_DEFAULT',     'true');
define('MODULE_ADDON_MODULES_AJAXCATEGORYTREE_SORT_ORDER_DEFAULT', '');
?>