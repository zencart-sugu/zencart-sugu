<?php
if (!defined('IS_ADMIN_FLAG')) {
  die('Illegal Access');
}
define('MODULE_ADDON_MODULES_HELP_STATUS_DEFAULT', 'true');
define('MODULE_ADDON_MODULES_HELP_SORT_ORDER_DEFAULT', '');
?>